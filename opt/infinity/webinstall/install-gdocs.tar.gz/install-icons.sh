#!/bin/bash

cp ./google-drive.png /usr/share/icons/hicolor/128x128/apps/
cp ./google-docs.png /usr/share/icons/hicolor/128x128/apps/
cp ./google-sheets.png /usr/share/icons/hicolor/128x128/apps/
cp ./google-slides.png /usr/share/icons/hicolor/128x128/apps/

update-icon-caches /usr/share/icons/hicolor

exit 0