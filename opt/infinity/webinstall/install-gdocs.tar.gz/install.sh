#!/bin/bash

gksudo ./install-icons.sh


BROWSER='x-www-browser'
if [ -x "/usr/bin/google-chrome" ];then
	#Use Google Chrome
	BROWSER='/usr/bin/google-chrome'
else
	if [ -x "/usr/bin/chromium" ];then
		#Use Chromium
		BROWSER='/usr/bin/chromium'
	fi
fi


/opt/infinity/startmenu/startmenu-add "Google Docs" "$BROWSER http://docs.google.com" "google-docs"
/opt/infinity/startmenu/startmenu-add "Google Sheets" "$BROWSER http://sheets.google.com" "google-sheets"
/opt/infinity/startmenu/startmenu-add "Google Slides" "$BROWSER http://slides.google.com" "google-slides"

exit 0
