#!/bin/bash

if [ ! -x "/usr/bin/google-chrome" ];then
	if [ ! -x "/usr/bin/chromium" ];then
		zenity --info --title='Google Docs install' --text 'There was no Google Chrome or Chromium found on your system. You can proceed and install for another browser.'
		if [ "$?" = "1" ];then
			exit 1
		fi
	fi
fi

exit 0